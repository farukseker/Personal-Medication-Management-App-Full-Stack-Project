from django.apps import AppConfig


class MedicationManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medication_management'
