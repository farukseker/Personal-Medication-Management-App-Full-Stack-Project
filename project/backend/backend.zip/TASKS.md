* [ ] Bildirim sistemi -> alaram gibi ses çalabilir vs bilidirimlerde gözükmeli
* [ ] Eğer kullanıcı aynı ilacı 2. kez eklemek isterse kullanıcıyı uyar > front side

göme engelliler için özel nav ve elevnlabs ile seslendirme eklenebilir
stok yönetimi couut bazlı olabilir
Su içme | hedefi istatistiksel veri (1 aylık)